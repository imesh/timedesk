package org.timedesk.entity;

import org.springframework.roo.addon.test.RooIntegrationTest;
import org.timedesk.entity.ApplicationFeature;
import org.junit.Test;

@RooIntegrationTest(entity = ApplicationFeature.class)
public class ApplicationFeatureIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
