package org.timedesk.entity;

import org.springframework.roo.addon.test.RooIntegrationTest;
import org.timedesk.entity.EmployeeLeave;
import org.junit.Test;

@RooIntegrationTest(entity = EmployeeLeave.class)
public class EmployeeLeaveIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
