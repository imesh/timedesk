package org.timedesk.entity;

import org.springframework.roo.addon.test.RooIntegrationTest;
import org.timedesk.entity.EmployeeAllocation;
import org.junit.Test;

@RooIntegrationTest(entity = EmployeeAllocation.class)
public class EmployeeAllocationIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
