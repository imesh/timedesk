package org.timedesk.entity;

import org.springframework.roo.addon.test.RooIntegrationTest;
import org.timedesk.entity.EmployeeRole;
import org.junit.Test;

@RooIntegrationTest(entity = EmployeeRole.class)
public class EmployeeRoleIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
