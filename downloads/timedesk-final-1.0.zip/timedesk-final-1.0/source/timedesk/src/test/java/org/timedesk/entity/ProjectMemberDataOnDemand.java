package org.timedesk.entity;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import org.timedesk.entity.ProjectMember;

@RooDataOnDemand(entity = ProjectMember.class)
public class ProjectMemberDataOnDemand {
}
