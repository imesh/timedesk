package org.timedesk.entity;

import org.springframework.roo.addon.test.RooIntegrationTest;
import org.timedesk.entity.ProjectPhase;
import org.junit.Test;

@RooIntegrationTest(entity = ProjectPhase.class)
public class ProjectPhaseIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
