package org.timedesk.entity;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import org.timedesk.entity.EmployeeAllocation;

@RooDataOnDemand(entity = EmployeeAllocation.class)
public class EmployeeAllocationDataOnDemand {
}
