package org.timedesk.entity;

import org.springframework.roo.addon.test.RooIntegrationTest;
import org.timedesk.entity.Skill;
import org.junit.Test;

@RooIntegrationTest(entity = Skill.class)
public class SkillIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
