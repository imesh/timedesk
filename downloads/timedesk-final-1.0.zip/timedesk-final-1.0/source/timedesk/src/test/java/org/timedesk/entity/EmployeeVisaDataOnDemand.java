package org.timedesk.entity;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import org.timedesk.entity.EmployeeVisa;

@RooDataOnDemand(entity = EmployeeVisa.class)
public class EmployeeVisaDataOnDemand {
}
