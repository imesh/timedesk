package org.timedesk.entity;

import org.springframework.roo.addon.test.RooIntegrationTest;
import org.timedesk.entity.ProjectMemberFeedback;
import org.junit.Test;

@RooIntegrationTest(entity = ProjectMemberFeedback.class)
public class ProjectMemberFeedbackIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
