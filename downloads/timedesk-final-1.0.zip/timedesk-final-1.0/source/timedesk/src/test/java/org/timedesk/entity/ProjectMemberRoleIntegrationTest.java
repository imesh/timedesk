package org.timedesk.entity;

import org.springframework.roo.addon.test.RooIntegrationTest;
import org.timedesk.entity.ProjectMemberRole;
import org.junit.Test;

@RooIntegrationTest(entity = ProjectMemberRole.class)
public class ProjectMemberRoleIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
