package org.timedesk.entity;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import org.timedesk.entity.ProjectMemberFeedback;

@RooDataOnDemand(entity = ProjectMemberFeedback.class)
public class ProjectMemberFeedbackDataOnDemand {
}
