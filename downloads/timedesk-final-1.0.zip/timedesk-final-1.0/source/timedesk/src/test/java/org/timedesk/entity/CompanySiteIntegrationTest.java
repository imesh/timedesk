package org.timedesk.entity;

import org.springframework.roo.addon.test.RooIntegrationTest;
import org.timedesk.entity.CompanySite;
import org.junit.Test;

@RooIntegrationTest(entity = CompanySite.class)
public class CompanySiteIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
