package org.timedesk.entity;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import org.timedesk.entity.Company;

@RooDataOnDemand(entity = Company.class)
public class CompanyDataOnDemand {
}
