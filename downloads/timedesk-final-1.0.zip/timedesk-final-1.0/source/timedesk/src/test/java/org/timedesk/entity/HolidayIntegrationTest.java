package org.timedesk.entity;

import org.springframework.roo.addon.test.RooIntegrationTest;
import org.timedesk.entity.Holiday;
import org.junit.Test;

@RooIntegrationTest(entity = Holiday.class)
public class HolidayIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
