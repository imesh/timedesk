package org.timedesk.entity;

import org.springframework.roo.addon.test.RooIntegrationTest;
import org.timedesk.entity.ProjectMember;
import org.junit.Test;

@RooIntegrationTest(entity = ProjectMember.class)
public class ProjectMemberIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
