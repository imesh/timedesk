package org.timedesk.entity;

import org.springframework.roo.addon.test.RooIntegrationTest;
import org.timedesk.entity.Company;
import org.junit.Test;

@RooIntegrationTest(entity = Company.class)
public class CompanyIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
