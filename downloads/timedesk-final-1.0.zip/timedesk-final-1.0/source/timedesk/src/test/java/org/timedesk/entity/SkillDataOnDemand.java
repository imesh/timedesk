package org.timedesk.entity;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import org.timedesk.entity.Skill;

@RooDataOnDemand(entity = Skill.class)
public class SkillDataOnDemand {
}
