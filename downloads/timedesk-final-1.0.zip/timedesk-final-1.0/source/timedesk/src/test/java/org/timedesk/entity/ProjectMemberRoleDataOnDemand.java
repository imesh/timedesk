package org.timedesk.entity;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import org.timedesk.entity.ProjectMemberRole;

@RooDataOnDemand(entity = ProjectMemberRole.class)
public class ProjectMemberRoleDataOnDemand {
}
