package org.timedesk.entity;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import org.timedesk.entity.EmployeeLeave;

@RooDataOnDemand(entity = EmployeeLeave.class)
public class EmployeeLeaveDataOnDemand {
}
