package org.timedesk.entity;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import org.timedesk.entity.Project;

@RooDataOnDemand(entity = Project.class)
public class ProjectDataOnDemand {
}
