package org.timedesk.entity;

import org.springframework.roo.addon.test.RooIntegrationTest;
import org.timedesk.entity.ProjectPhaseMember;
import org.junit.Test;

@RooIntegrationTest(entity = ProjectPhaseMember.class)
public class ProjectPhaseMemberIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
