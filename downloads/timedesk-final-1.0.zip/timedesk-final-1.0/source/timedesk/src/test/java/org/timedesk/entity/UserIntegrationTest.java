package org.timedesk.entity;

import org.springframework.roo.addon.test.RooIntegrationTest;
import org.timedesk.entity.User;
import org.junit.Test;

@RooIntegrationTest(entity = User.class)
public class UserIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
