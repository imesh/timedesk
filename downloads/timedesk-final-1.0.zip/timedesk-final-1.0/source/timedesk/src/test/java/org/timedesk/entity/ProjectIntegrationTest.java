package org.timedesk.entity;

import org.springframework.roo.addon.test.RooIntegrationTest;
import org.timedesk.entity.Project;
import org.junit.Test;

@RooIntegrationTest(entity = Project.class)
public class ProjectIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
