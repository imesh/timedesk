package org.timedesk.entity;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import org.timedesk.entity.Holiday;

@RooDataOnDemand(entity = Holiday.class)
public class HolidayDataOnDemand {
}
