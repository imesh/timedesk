package org.timedesk.entity;

import org.springframework.roo.addon.test.RooIntegrationTest;
import org.timedesk.entity.EmployeeVisa;
import org.junit.Test;

@RooIntegrationTest(entity = EmployeeVisa.class)
public class EmployeeVisaIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
