package org.timedesk.web.util;

public enum NotificationEnum
{
	AssignedToProject, AllocatedToProject, UnAssignedFromProject, DeAllocatedFromProject
}
